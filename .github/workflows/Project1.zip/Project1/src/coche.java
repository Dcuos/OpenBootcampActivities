public class coche {
    public int puertas = numeroPuertas(0);

    public int numeroPuertas(int i) {
        return puertas++;
    }
}


