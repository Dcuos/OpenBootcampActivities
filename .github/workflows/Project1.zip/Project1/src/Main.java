public class Main {
    public static void main(String[] args) {
        int resultant = suma(1,2, 3);
        System.out.println(resultant);
    }

    public static int suma(int a, int b, int c){
        return a + b + c;
    }
}